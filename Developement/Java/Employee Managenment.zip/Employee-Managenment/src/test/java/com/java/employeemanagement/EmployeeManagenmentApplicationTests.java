package com.java.employeemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeManagenmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
